git add . && git commit -am 'fixes' && git push origin master

